# Preise für die Slot Machine
# Diese Listen können vor dem Stream angepasst werden

# Hauptpreis (3x Lugia)
JACKPOT_PRIZE = "M Charizard EX 69/106"

# Preise für 3 gleiche Symbole (außer Lugia)
MAIN_PRIZES = [
    "M Mewtwo Ex 64/162",
    "M Blastoise EX 30/146",
    "M Sharpedo EX xy200",
    "M Glalie Ex 156/182",
    "M Gardevoir Ex 112/114",
]

# Preise für 2 gleiche Symbole
DOUBLE_PRIZES = [
    "2 x japanische Booster",
    "2 x japanische booster",
    "1 x Japanisicher Booster",
]

# Preise für keine Übereinstimmungen
EASY_PRIZES = [
    "Art rare karte",
    "Art Rare Karte",
]
