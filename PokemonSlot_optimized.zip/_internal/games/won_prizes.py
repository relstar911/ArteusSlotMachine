# Liste der bereits gewonnenen Preise
WON_PRIZES = []
